Product.create(
    title: 'Lightweight Jacket',
    description:%{<p><em>Nulla eget sem vitae eros pharetra viverra. Nam vitae luctus ligula. Mauris consequat ornare feugiat.</p>},
    image_url: 'product-01.jpg',
    price: 40.00)
Product.create(
    title: 'Esprit Ruffle Shirt',
    description:%{<p><em>Nulla eget sem vitae eros pharetra viverra. Nam vitae luctus ligula. Mauris consequat ornare feugiat.</p>},
    image_url: 'product-02.jpg',
    price: 33.00)
Product.create(
    title: 'Femme T-Shirt In Stripe',
    description:%{<p><em>Nulla eget sem vitae eros pharetra viverra. Nam vitae luctus ligula. Mauris consequat ornare feugiat.</p>},
    image_url: 'product-03.jpg',
    price: 14.00)
Product.create(
    title: 'Only Check Trouser',
    description:%{<p><em>Nulla eget sem vitae eros pharetra viverra. Nam vitae luctus ligula. Mauris consequat ornare feugiat.</p>},
    image_url: 'product-04.jpg',
    price: 36.00)
Product.create(
    title: 'Shirt in Stretch Cotton',
    description:%{<p><em>Nulla eget sem vitae eros pharetra viverra. Nam vitae luctus ligula. Mauris consequat ornare feugiat.</p>},
    image_url: 'product-05.jpg',
    price: 20.00)
Product.create(
    title: 'Pieces Metallic Printed',
    description:%{<p><em>Nulla eget sem vitae eros pharetra viverra. Nam vitae luctus ligula. Mauris consequat ornare feugiat.</p>},
    image_url: 'product-06.jpg',
    price: 42.00)


User.create({email: "hoangmy121097@gmail.com", password: "123456", password_confirmation: "123456"})